/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//49. Mostrar el número anterior y posterior al ingresado.
#include <iostream>
using namespace std;
int main() {
    int n;
    cout << "Ingrese un número: ";
    cin >> n;
    cout << "Número anterior: " << n - 1 << ", posterior: " << n + 1 << endl;
    return 0;
}











