/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//55. Convertir dólares a euros.
#include <iostream>
using namespace std;
int main() {
    double dolares, tasa;
    cout << "Ingrese cantidad en dólares: "; cin >> dolares;
    cout << "Tasa de cambio (1 dólar a euros): "; cin >> tasa;
    cout << "Equivalente en euros: " << dolares * tasa << endl;
    return 0;
}











