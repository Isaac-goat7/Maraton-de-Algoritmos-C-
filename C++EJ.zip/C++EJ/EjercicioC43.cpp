/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//43. Calcular el consumo de combustible.
#include <iostream>
using namespace std;
int main() {
    double distancia, litros;
    cout << "Distancia recorrida (km): "; cin >> distancia;
    cout << "Combustible consumido (L): "; cin >> litros;
    cout << "Consumo promedio: " << distancia / litros << " km/L" << endl;
    return 0;
}










