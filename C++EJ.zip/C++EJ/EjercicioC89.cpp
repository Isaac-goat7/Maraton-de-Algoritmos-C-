/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//89. Calcular el perímetro de un triángulo.
#include <iostream>
using namespace std;
int main() {
    double a, b, c;
    cout << "Ingrese los lados del triángulo: "; cin >> a >> b >> c;
    double perimetro = a + b + c;
    cout << "Perímetro del triángulo: " << perimetro << endl;
    return 0;
}












