/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//63. Calcular el perímetro de un cuadrado.
#include <iostream>
using namespace std;
int main() {
    double lado;
    cout << "Lado del cuadrado: "; cin >> lado;
    cout << "Perímetro: " << 4 * lado << endl;
    return 0;
}














