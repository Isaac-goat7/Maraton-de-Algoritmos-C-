/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//36. Convertir kilogramos a gramos.
#include <iostream>
using namespace std;
int main() {
    double kg;
    cout << "Kilogramos: ";
    cin >> kg;
    cout << kg << " kg equivalen a " << kg * 1000 << " g." << endl;
    return 0;
}







