/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//78. Convertir kilogramos a libras.
#include <iostream>
using namespace std;
int main() {
    double kg;
    cout << "Ingrese kilogramos: "; cin >> kg;
    double libras = kg / 0.453592;
    cout << "Equivalente en libras: " << libras << endl;
    return 0;
}






