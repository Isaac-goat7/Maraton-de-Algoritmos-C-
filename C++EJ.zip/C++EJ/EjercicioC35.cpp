/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//35. Convertir gramos a kilogramos.
#include <iostream>
using namespace std;
int main() {
    double g;
    cout << "Gramos: ";
    cin >> g;
    cout << g << " g equivalen a " << g / 1000 << " kg." << endl;
    return 0;
}





