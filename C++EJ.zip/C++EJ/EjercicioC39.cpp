/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//39. Calcular el perímetro de un triángulo equilátero.
#include <iostream>
using namespace std;
int main() {
    double lado;
    cout << "Lado del triángulo: ";
    cin >> lado;
    cout << "Perímetro: " << lado * 3 << endl;
    return 0;
}








