/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//62. Calcular la fuerza aplicando la segunda ley de Newton.
#include <iostream>
using namespace std;
int main() {
    double masa, aceleracion;
    cout << "Masa (kg): "; cin >> masa;
    cout << "Aceleración (m/s^2): "; cin >> aceleracion;
    cout << "Fuerza resultante: " << masa * aceleracion << " N" << endl;
    return 0;
}













