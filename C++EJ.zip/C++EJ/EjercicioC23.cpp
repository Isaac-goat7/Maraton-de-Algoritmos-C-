/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//23. Convertir millas a kilómetros.
#include <iostream>
using namespace std;
int main() {
    double mi;
    cout << "Millas: ";
    cin >> mi;
    cout << "Kilómetros: " << mi / 0.621371 << endl;
    return 0;
}











