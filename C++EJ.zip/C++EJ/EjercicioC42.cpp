/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//42. Calcular la distancia si se conoce tiempo y velocidad.
#include <iostream>
using namespace std;
int main() {
    double tiempo, velocidad;
    cout << "Tiempo (h): "; cin >> tiempo;
    cout << "Velocidad (km/h): "; cin >> velocidad;
    cout << "Distancia = " << velocidad * tiempo << " km." << endl;
    return 0;
}









