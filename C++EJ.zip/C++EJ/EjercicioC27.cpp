/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//27. Calcular el área de un paralelogramo.
#include <iostream>
using namespace std;
int main() {
    double base, altura;
    cout << "Base: ";
    cin >> base;
    cout << "Altura: ";
    cin >> altura;
    cout << "Área del paralelogramo: " << base * altura << endl;
    return 0;
}

