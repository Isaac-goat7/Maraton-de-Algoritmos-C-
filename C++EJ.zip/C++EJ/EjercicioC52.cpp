/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//52. Calcular la media aritmética de cinco números.
#include <iostream>
using namespace std;
int main() {
    double a, b, c, d, e;
    cout << "Ingrese cinco números: ";
    cin >> a >> b >> c >> d >> e;
    double media = (a + b + c + d + e) / 5;
    cout << "Media aritmética: " << media << endl;
    return 0;
}











