/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//65. Calcular la presión (P = F / A).
#include <iostream>
using namespace std;
int main() {
    double fuerza, area;
    cout << "Fuerza (N): "; cin >> fuerza;
    cout << "Área (m^2): "; cin >> area;
    cout << "Presión: " << fuerza / area << " Pa" << endl;
    return 0;
}
















