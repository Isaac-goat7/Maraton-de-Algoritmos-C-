/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//77. Convertir libras a kilogramos.
#include <iostream>
using namespace std;
int main() {
    double libras;
    cout << "Ingrese libras: "; cin >> libras;
    double kg = libras * 0.453592; // 1 libra = 0.453592 kg
    cout << "Equivalente en kg: " << kg << endl;
    return 0;
}





