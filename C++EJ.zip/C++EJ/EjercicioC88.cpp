/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//88. Calcular el perímetro de un rectángulo.
#include <iostream>
using namespace std;
int main() {
    double base, altura;
    cout << "Base: "; cin >> base;
    cout << "Altura: "; cin >> altura;
    double perimetro = 2 * (base + altura);
    cout << "Perímetro del rectángulo: " << perimetro << endl;
    return 0;
}












