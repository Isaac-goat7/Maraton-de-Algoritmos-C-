/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//58. Calcular el perímetro y área de un rectángulo.
#include <iostream>
using namespace std;
int main() {
    double base, altura;
    cout << "Base: "; cin >> base;
    cout << "Altura: "; cin >> altura;
    cout << "Perímetro: " << 2 * (base + altura) << endl;
    cout << "Área: " << base * altura << endl;
    return 0;
}









