/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//24. Calcular edad a partir del año de nacimiento.
#include <iostream>
using namespace std;
int main() {
    int nacimiento, actual;
    cout << "Ingrese su año de nacimiento: ";
    cin >> nacimiento;
    cout << "Ingrese el año actual: ";
    cin >> actual;
    cout << "Su edad es: " << actual - nacimiento << " años." << endl;
    return 0;
}











