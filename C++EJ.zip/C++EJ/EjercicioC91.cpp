/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//91. Calcular el promedio de cuatro números.
#include <iostream>
using namespace std;
int main() {
    double a, b, c, d;
    cout << "Ingrese cuatro números: "; cin >> a >> b >> c >> d;
    double promedio = (a + b + c + d) / 4;
    cout << "Promedio: " << promedio << endl;
    return 0;
}











