/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//32. Calcular el área total de un cubo.
#include <iostream>
#include <cmath>
using namespace std;
int main() {
    double arista;
    cout << "Arista del cubo: ";
    cin >> arista;
    cout << "Área total del cubo: " << 6 * pow(arista, 2) << endl; // 6 * L²
    return 0;
}





