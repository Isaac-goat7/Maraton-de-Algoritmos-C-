/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//64. Convertir una cantidad en horas a segundos.
#include <iostream>
using namespace std;
int main() {
    double horas;
    cout << "Ingrese horas: "; cin >> horas;
    cout << "Equivalente en segundos: " << horas * 3600 << endl;
    return 0;
}















