/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//33. Convertir centímetros a metros.
#include <iostream>
using namespace std;
int main() {
    double cm;
    cout << "Centímetros: ";
    cin >> cm;
    cout << cm << " cm equivalen a " << cm / 100 << " m." << endl;
    return 0;
}




