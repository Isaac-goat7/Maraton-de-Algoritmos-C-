/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//22. Convertir kilómetros a millas.
#include <iostream>
using namespace std;
int main() {
    double km;
    cout << "Kilómetros: ";
    cin >> km;
    cout << "Millas: " << km * 0.621371 << endl;
    return 0;
}










