/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//59. Calcular el promedio de edad de tres personas.
#include <iostream>
using namespace std;
int main() {
    int e1, e2, e3;
    cout << "Ingrese tres edades: ";
    cin >> e1 >> e2 >> e3;
    cout << "Promedio de edad: " << (e1 + e2 + e3) / 3.0 << endl;
    return 0;
}










