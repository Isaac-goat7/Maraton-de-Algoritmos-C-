/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//50. Mostrar el cuadrado y el cubo de un número.
#include <iostream>
#include <cmath>
using namespace std;
int main() {
    double n;
    cout << "Ingrese un número: ";
    cin >> n;
    cout << "Cuadrado: " << pow(n, 2) << ", Cubo: " << pow(n, 3) << endl;
    return 0;
}











