/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//93. Convertir kilómetros a millas.
#include <iostream>
using namespace std;
int main() {
    double km;
    cout << "Ingrese kilómetros: "; cin >> km;
    double millas = km * 0.621371; // 1 km ≈ 0.621371 millas
    cout << "Equivalente en millas: " << millas << endl;
    return 0;
}













