/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//56. Calcular el costo total de artículos comprados.
#include <iostream>
using namespace std;
int main() {
    double precioUnitario;
    int cantidad;
    cout << "Precio unitario: "; cin >> precioUnitario;
    cout << "Cantidad comprada: "; cin >> cantidad;
    cout << "Total a pagar: $" << precioUnitario * cantidad << endl;
    return 0;
}








