/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//68. Convertir años a días y meses (aproximado).
#include <iostream>
using namespace std;
int main() {
    int años;
    cout << "Ingrese años: "; cin >> años;
    cout << "Equivale a " << años * 12 << " meses o " << años * 365 << " días." << endl;
    return 0;
}


















