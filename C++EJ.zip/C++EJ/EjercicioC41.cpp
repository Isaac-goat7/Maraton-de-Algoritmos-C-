/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//41. Calcular el tiempo si se conoce velocidad y distancia.
#include <iostream>
using namespace std;
int main() {
    double distancia, velocidad;
    cout << "Distancia (km): "; cin >> distancia;
    cout << "Velocidad (km/h): "; cin >> velocidad;
    cout << "Tiempo = " << distancia / velocidad << " horas." << endl;
    return 0;
}








