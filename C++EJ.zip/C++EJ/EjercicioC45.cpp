/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Gloder Rodriguez
//45. Calcular el promedio de calificaciones de un estudiante.
#include <iostream>
using namespace std;
int main() {
    double n1, n2, n3;
    cout << "Ingrese tres notas: ";
    cin >> n1 >> n2 >> n3;
    double promedio = (n1 + n2 + n3) / 3;
    cout << "Promedio: " << promedio << endl;
    return 0;
}











